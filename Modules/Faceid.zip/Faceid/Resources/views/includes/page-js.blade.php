<!-- ================== BEGIN core-js ================== -->
<script src="{{ asset('/js/vendor.min.js') }}"></script>
<script src="{{ asset('/js/app.min.js') }}"></script>
<!-- ================== END core-js ================== -->

@stack('scripts')