<div class="navbar-item dropdown">
	<a href="#" class="navbar-link dropdown-toggle" data-bs-toggle="dropdown">
		<span class="flag-icon flag-icon-us" title="us"></span>
		<span class="d-none d-sm-inline ms-1">EN</span> <b class="caret"></b>
	</a>
	<div class="dropdown-menu dropdown-menu-end">
		<a href="javascript:;" class="dropdown-item"><span class="flag-icon flag-icon-us me-2" title="us"></span> English</a>
		<a href="javascript:;" class="dropdown-item"><span class="flag-icon flag-icon-cn me-2" title="cn"></span> Chinese</a>
		<a href="javascript:;" class="dropdown-item"><span class="flag-icon flag-icon-jp me-2" title="jp"></span> Japanese</a>
		<a href="javascript:;" class="dropdown-item"><span class="flag-icon flag-icon-be me-2" title="be"></span> Belgium</a>
		<div class="dropdown-divider"></div>
		<a href="javascript:;" class="dropdown-item text-center">more options</a>
	</div>
</div>